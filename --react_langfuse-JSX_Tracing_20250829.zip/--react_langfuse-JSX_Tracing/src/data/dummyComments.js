export const dummyComments = [
  {
    id: 1,
    author: 'test',
    email: 'test@test.test',
    timestamp: '0 minutes ago',
    content: 'ㅌㅅㅌ',
  },
];