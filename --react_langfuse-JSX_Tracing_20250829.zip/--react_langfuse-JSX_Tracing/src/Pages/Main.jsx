const Main = () => {
  return (
    <div>Main</div>
  )
}

export default Main